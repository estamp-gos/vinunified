<?php
// success.php - Payment Success Page
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful | VinUnified</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #6C63FF, #00B4D8);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .success-container {
            max-width: 500px;
            width: 100%;
        }
        .success-card {
            background: white;
            border-radius: 24px;
            padding: 50px 40px;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .checkmark {
            width: 80px;
            height: 80px;
            background: #28A745;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
        }
        .checkmark svg {
            width: 50px;
            height: 50px;
            color: white;
        }
        h1 {
            color: #03045E;
            font-size: 28px;
            margin-bottom: 15px;
        }
        p {
            color: #6C757D;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        .btn-home {
            display: inline-block;
            background: linear-gradient(135deg, #6C63FF, #00B4D8);
            color: white;
            text-decoration: none;
            padding: 14px 35px;
            border-radius: 50px;
            font-weight: 600;
            margin-top: 25px;
            transition: all 0.3s;
        }
        .btn-home:hover {
            transform: scale(1.02);
            box-shadow: 0 10px 20px rgba(108,99,255,0.3);
        }
        .footer {
            margin-top: 20px;
            font-size: 12px;
            color: rgba(255,255,255,0.7);
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-card">
            <div class="checkmark">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7" />
                </svg>
            </div>
            <h1>Payment Successful! 🎉</h1>
            <p>Thank you for your purchase.</p>
            <p>Your vehicle history report will be sent to your email within <strong>1-2 hours</strong>.</p>
            <p style="font-size: 13px; background: #FFF3CD; padding: 10px; border-radius: 10px; margin-top: 15px;">
                ⚠️ Please check your <strong>spam/junk folder</strong> if you don't see the email.
            </p>
            <a href="https://vinunified.store" class="btn-home">← Back to Home</a>
        </div>
        <div class="footer">
            <p>VinUnified | One VIN. Global History.</p>
        </div>
    </div>
</body>
</html>