-- sql/database.sql - Database Schema

CREATE DATABASE IF NOT EXISTS `vinunified_db`;
USE `vinunified_db`;

-- Table for storing VIN requests
CREATE TABLE IF NOT EXISTS `vin_requests` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `full_name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(20) NOT NULL,
    `vin` VARCHAR(17) DEFAULT NULL,
    `license_plate` VARCHAR(20) DEFAULT NULL,
    `vehicle_type` VARCHAR(50) NOT NULL,
    `package` VARCHAR(20) NOT NULL,
    `status` ENUM('pending', 'paid', 'delivered', 'refunded') DEFAULT 'pending',
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_email` (`email`),
    INDEX `idx_vin` (`vin`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample data (optional)
-- INSERT INTO `vin_requests` (`full_name`, `email`, `phone`, `vin`, `vehicle_type`, `package`, `status`) 
-- VALUES ('Test User', 'test@example.com', '1234567890', '1HGCM82633A123456', 'Car', 'basic', 'paid');

-- Cron job for 30-day auto deletion
-- DELETE FROM vin_requests WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);