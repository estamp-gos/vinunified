<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle History Audit Report | VinUnified</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: #E8ECEF;
            padding: 30px 20px;
        }

        /* Main Container - NO FIXED HEIGHT, NO PAGE BREAKS */
        .report {
            max-width: 1100px;
            margin: 0 auto;
            background: #FFFFFF;
            box-shadow: 0 30px 60px rgba(0,0,0,0.12);
            border-radius: 32px;
            overflow: hidden;
        }

        /* NO PAGE BREAKS - Everything in one flow */
        .no-page-break {
            break-inside: avoid;
            page-break-inside: avoid;
        }

        /* ============================================ */
        /* PREMIUM HEADER */
        /* ============================================ */
        .premium-header {
            background: linear-gradient(135deg, #0A0A1A 0%, #1A1A3A 100%);
            padding: 48px 48px 40px;
            position: relative;
            overflow: hidden;
        }
        
        .premium-header::before {
            content: '';
            position: absolute;
            top: -30%;
            right: -10%;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(108,99,255,0.15) 0%, transparent 70%);
            border-radius: 50%;
        }

        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 40px;
            position: relative;
            z-index: 2;
        }

        .logo img {
            height: 52px;
        }

        .report-id {
            background: rgba(108,99,255,0.2);
            backdrop-filter: blur(10px);
            padding: 8px 20px;
            border-radius: 100px;
            font-size: 13px;
            color: #A9A9FF;
            border: 1px solid rgba(108,99,255,0.4);
        }

        .vehicle-badge {
            display: inline-block;
            background: rgba(255,255,255,0.08);
            padding: 6px 16px;
            border-radius: 100px;
            font-size: 13px;
            color: #A9A9FF;
            margin-bottom: 20px;
        }

        .vehicle-title {
            font-size: 36px;
            font-weight: 700;
            color: white;
            letter-spacing: -0.5px;
            margin-bottom: 16px;
        }

        .plate-highlight {
            display: inline-block;
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(8px);
            padding: 8px 28px;
            border-radius: 100px;
            font-family: monospace;
            font-size: 20px;
            letter-spacing: 3px;
            color: #FFD700;
            margin-top: 8px;
        }

        .key-metrics {
            display: flex;
            gap: 48px;
            flex-wrap: wrap;
            margin-top: 40px;
            padding-top: 24px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        .metric {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .metric-label {
            font-size: 13px;
            color: #8E8EA8;
            letter-spacing: 0.5px;
        }
        .metric-value {
            font-size: 24px;
            font-weight: 700;
            color: white;
        }

        /* ============================================ */
        /* STATS CARDS - MODERN GLASS */
        /* ============================================ */
        .stats-premium {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            background: #F8F9FF;
            border-bottom: 1px solid #EDEFF5;
        }
        .stat-premium {
            padding: 28px 16px;
            text-align: center;
            border-right: 1px solid #EDEFF5;
            transition: all 0.2s;
        }
        .stat-premium:last-child { border-right: none; }
        .stat-premium i { font-size: 34px; color: #6C63FF; margin-bottom: 12px; display: block; }
        .stat-number { font-size: 32px; font-weight: 800; color: #1A1A2E; }
        .stat-label { font-size: 12px; color: #6C6C8A; margin-top: 6px; font-weight: 500; }

        /* ============================================ */
        /* CONTENT BLOCKS */
        /* ============================================ */
        .content-block {
            padding: 32px 48px;
            border-bottom: 1px solid #F0F2F8;
        }
        .block-title {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 28px;
        }
        .block-title i {
            font-size: 28px;
            color: #6C63FF;
            background: #F0EFFE;
            padding: 10px;
            border-radius: 16px;
        }
        .block-title h2 {
            font-size: 20px;
            font-weight: 700;
            color: #1A1A2E;
            letter-spacing: -0.3px;
        }

        /* Grids */
        .two-col {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px 32px;
        }
        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px dashed #EDEFF5;
        }
        .info-label {
            font-weight: 500;
            color: #6C6C8A;
            font-size: 14px;
        }
        .info-value {
            font-weight: 600;
            color: #1A1A2E;
            font-size: 14px;
        }

        /* Three Column */
        .three-col {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px 24px;
        }

        /* Brand Grid - Premium */
        .brands-premium {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-top: 8px;
        }
        .brand-card {
            background: #F8F9FF;
            border-radius: 16px;
            padding: 14px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.2s;
            border: 1px solid transparent;
        }
        .brand-card:hover { border-color: #6C63FF20; background: white; }
        .brand-name { font-weight: 500; font-size: 13px; color: #2A2A4A; }
        .brand-status { font-weight: 700; font-size: 16px; }
        .brand-status.clean { color: #28A745; }
        .brand-status.warning { color: #DC3545; }

        /* Badges */
        .badge-premium {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 100px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge-clean { background: #E6F7E6; color: #1E7E34; }
        .badge-equipped { background: #E8ECFF; color: #4A42D1; }
        .badge-warning { background: #FFF3E0; color: #E67E22; }

        /* Recall Card */
        .recall-premium {
            background: #F8F9FF;
            border-radius: 20px;
            padding: 24px;
            border-left: 5px solid #28A745;
            margin-bottom: 28px;
        }

        /* Disclaimer & Footer */
        .disclaimer-premium {
            background: #F8F9FF;
            padding: 24px 48px;
            font-size: 11px;
            color: #8E8EA8;
            text-align: center;
            line-height: 1.5;
            border-top: 1px solid #EDEFF5;
        }
        .footer-premium {
            background: #0A0A1A;
            padding: 24px 48px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
        }
        .footer-logo img { height: 36px; opacity: 0.8; }
        .footer-text { color: #8E8EA8; font-size: 12px; }
        .footer-badge { color: #6C63FF; font-size: 12px; }

        /* Button */
        .save-pdf-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #6C63FF;
            color: white;
            border: none;
            padding: 14px 28px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            z-index: 1000;
            box-shadow: 0 10px 25px rgba(108,99,255,0.3);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .save-pdf-btn:hover {
            background: #4A42D1;
            transform: scale(1.02);
        }

        /* Responsive */
        @media (max-width: 780px) {
            .content-block { padding: 24px; }
            .stats-premium { grid-template-columns: repeat(3, 1fr); }
            .two-col, .three-col { grid-template-columns: 1fr; }
            .brands-premium { grid-template-columns: repeat(2, 1fr); }
            .vehicle-title { font-size: 24px; }
            .premium-header { padding: 32px; }
        }
        @media (max-width: 500px) {
            .brands-premium { grid-template-columns: 1fr; }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>
<body>

<!--<button class="save-pdf-btn" id="savePdfBtn">-->
<!--    <i class="fas fa-download"></i> Save as PDF (Single Page)-->
<!--</button>-->

<div class="report" id="reportContainer">

    <!-- HEADER SECTION -->
    <div class="premium-header">
        <div class="header-flex">
            <div class="logo"><img src="https://vinunified.store/assets/images/vinunified-white.png" alt="VinUnified"></div>
            <div class="report-id"><i class="fas fa-fingerprint"></i> Report ID: VIN-20260601-001</div>
        </div>
        <div class="vehicle-badge"><i class="fas fa-certificate"></i> Official Vehicle History Audit Report | Comprehensive & Detailed</div>
        <div class="vehicle-title">VOLKSWAGEN TRANSPORTER<br>T28 TDI P/V HIGHLINE</div>
        <div class="plate-highlight"><i class="fas fa-tag"></i> T 4 0 V A C</div>
        <div class="key-metrics">
            <div class="metric"><span class="metric-label">Year / Model</span><span class="metric-value">2013</span></div>
            <div class="metric"><span class="metric-label">Current Mileage</span><span class="metric-value">190,000 mi</span></div>
            <div class="metric"><span class="metric-label">Market Value</span><span class="metric-value">£9,000</span></div>
            <div class="metric"><span class="metric-label">Search Date</span><span class="metric-value">1 June 2026</span></div>
        </div>
    </div>

    <!-- STATS ROW -->
    <div class="stats-premium">
        <div class="stat-premium"><i class="fas fa-car-crash"></i><div class="stat-number">0</div><div class="stat-label">Accidents</div></div>
        <div class="stat-premium"><i class="fas fa-bell"></i><div class="stat-number">0</div><div class="stat-label">Recalls</div></div>
        <div class="stat-premium"><i class="fas fa-file-contract"></i><div class="stat-number">0</div><div class="stat-label">Title Records</div></div>
        <div class="stat-premium"><i class="fas fa-dumpster"></i><div class="stat-number">0</div><div class="stat-label">Junk/Salvage</div></div>
        <div class="stat-premium"><i class="fas fa-fire-extinguisher"></i><div class="stat-number">0</div><div class="stat-label">Total Loss</div></div>
        <div class="stat-premium"><i class="fas fa-clipboard-list"></i><div class="stat-number">0</div><div class="stat-label">Problem Checks</div></div>
    </div>

    <!-- PAGE 1: Executive Summary & Vehicle Identity -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-file-alt"></i><h2>Executive Summary & Vehicle Identity</h2></div>
        <div class="two-col">
            <div class="info-row"><span class="info-label">Vehicle</span><span class="info-value">VOLKSWAGEN TRANSPORTER<br>T28 TDI P/V HIGHLINE (2013)</span></div>
            <div class="info-row"><span class="info-label">Plate Number</span><span class="info-value">T 40 VAC</span></div>
            <div class="info-row"><span class="info-label">Current Mileage</span><span class="info-value">190,000 miles</span></div>
            <div class="info-row"><span class="info-label">Title Records</span><span class="info-value"><span class="badge-premium badge-clean">No Records Found</span></span></div>
            <div class="info-row"><span class="info-label">Accidents</span><span class="info-value"><span class="badge-premium badge-clean">No Records Found</span></span></div>
            <div class="info-row"><span class="info-label">Junk/Salvage</span><span class="info-value"><span class="badge-premium badge-clean">No Records Found</span></span></div>
            <div class="info-row"><span class="info-label">Total Loss</span><span class="info-value"><span class="badge-premium badge-clean">No Records Found</span></span></div>
            <div class="info-row"><span class="info-label">Problem Checks</span><span class="info-value"><span class="badge-premium badge-clean">No Records Found</span></span></div>
            <div class="info-row"><span class="info-label">Recalls</span><span class="info-value"><span class="badge-premium badge-clean">No Records Found</span></span></div>
        </div>
    </div>

    <!-- PAGE 2: Core Vehicle Specifications -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-car"></i><h2>Core Vehicle Specifications</h2></div>
        <div class="two-col">
            <div class="info-row"><span class="info-label">Colour</span><span class="info-value">Blue</span></div>
            <div class="info-row"><span class="info-label">Engine</span><span class="info-value">1,968 cc / Turbocharged Diesel</span></div>
            <div class="info-row"><span class="info-label">Max Torque</span><span class="info-value">340 Nm @ 1,750 rpm</span></div>
            <div class="info-row"><span class="info-label">Top Speed</span><span class="info-value">107 mph</span></div>
            <div class="info-row"><span class="info-label">Gearbox</span><span class="info-value">6 Speed Manual</span></div>
            <div class="info-row"><span class="info-label">Market Value</span><span class="info-value">£9,000</span></div>
            <div class="info-row"><span class="info-label">MOT Status</span><span class="info-value"><span class="badge-premium badge-clean">Clear</span></span></div>
            <div class="info-row"><span class="info-label">Last Reported Mileage</span><span class="info-value">190,000 miles</span></div>
            <div class="info-row"><span class="info-label">Estimated Mileage</span><span class="info-value">189,000 miles</span></div>
        </div>
    </div>
<br><br>
    <!-- PAGE 3: General Status & Basic History -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-chart-simple"></i><h2>General Status & Basic History</h2></div>
        <div class="two-col">
            <div class="info-row"><span class="info-label">Vehicle Class</span><span class="info-value">39</span></div>
            <div class="info-row"><span class="info-label">Consumption (City)</span><span class="info-value">28.8 mpg</span></div>
            <div class="info-row"><span class="info-label">MOT Status</span><span class="info-value"><span class="badge-premium badge-clean">Current (Valid)</span></span></div>
            <div class="info-row"><span class="info-label">Sleep Capacity</span><span class="info-value">2</span></div>
        </div>
        <div style="margin-top: 24px; background: #E6F7E6; padding: 18px; border-radius: 20px; display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
            <i class="fas fa-check-circle" style="font-size: 28px; color: #28A745;"></i>
            <span><strong>Great News!</strong> No accident or junk/salvage records have been reported by any state authority.</span>
        </div>
    </div>

    <!-- PAGES 4-8: Title Brand & Problem Checks (Complete 50+ Checks) -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-gavel"></i><h2>Title Brand & Problem Checks (Comprehensive)</h2></div>
        
        <h3 style="margin: 0 0 16px 0; font-size: 16px; color: #6C63FF;"><i class="fas fa-water"></i> Damage & Salvage Checks</h3>
        <div class="brands-premium">
            <div class="brand-card"><span class="brand-name">Flood Damage</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Fire Damage</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Hail Damage</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Junk</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Totaled</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Salvage</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Former Rental</span><span class="brand-status clean">✓ No</span></div>
        </div>

        <h3 style="margin: 28px 0 16px 0; font-size: 16px; color: #6C63FF;"><i class="fas fa-history"></i> Title History Checks</h3>
        <div class="brands-premium">
            <div class="brand-card"><span class="brand-name">Prior Taxi</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Odometer Not Actual</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Vandalism</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Rebuilt</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Dismantled</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Collision</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Prior Police</span><span class="brand-status clean">✓ No</span></div>
        </div>

        <h3 style="margin: 28px 0 16px 0; font-size: 16px; color: #6C63FF;"><i class="fas fa-file-signature"></i> Warranty & Status Checks</h3>
        <div class="brands-premium">
            <div class="brand-card"><span class="brand-name">Warranty Return</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Parts Only</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Recovered Theft</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Undisclosed Lien</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Antique / Classic</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Agricultural Vehicle</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Reissued VIN</span><span class="brand-status clean">✓ No</span></div>
        </div>

        <h3 style="margin: 28px 0 16px 0; font-size: 16px; color: #6C63FF;"><i class="fas fa-shield-alt"></i> Safety & Defect Checks</h3>
        <div class="brands-premium">
            <div class="brand-card"><span class="brand-name">Manufacturer Buy Back</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Salvage / Stolen</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Crushed</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Inoperable Vehicle</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Hazardous</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Export Only Vehicle</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Odometer Tampering</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Gray Market</span><span class="brand-status clean">✓ No</span></div>
        </div>

        <h3 style="margin: 28px 0 16px 0; font-size: 16px; color: #6C63FF;"><i class="fas fa-tachometer-alt"></i> Odometer & Discrepancy Checks</h3>
        <div class="brands-premium">
            <div class="brand-card"><span class="brand-name">Odometer Exceeds Limits</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Odometer Altered</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Odometer Replaced</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Odometer Discrepancy</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Pending Junk</span><span class="brand-status clean">✓ No</span></div>
            <div class="brand-card"><span class="brand-name">Junk Automobile</span><span class="brand-status clean">✓ No</span></div>
        </div>

        <!-- Recalls Section -->
        <div class="recall-premium" style="margin-top: 28px;">
            <i class="fas fa-exclamation-triangle" style="color: #E67E22; margin-right: 12px;"></i>
            <strong>Recalls Section</strong>
            <div style="margin-top: 8px;"><span class="badge-premium badge-clean"><i class="fas fa-check"></i> No Active Campaigns Found</span></div>
            <div style="margin-top: 5px; font-size: 13px; color: #4A4A6A;">No manufacturer campaigns or active recalls have been reported for this vehicle.</div>
        </div>
    </div>
<br><br><br>
    <!-- PAGE 9: Engine & Transmission Technical Details -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-microchip"></i><h2>Engine & Transmission Technical Details</h2></div>
        <div class="two-col">
            <div class="info-row"><span class="info-label">Cylinders</span><span class="info-value">4</span></div>
            <div class="info-row"><span class="info-label">Cam Type</span><span class="info-value">DOHC (Double Overhead Camshaft)</span></div>
            <div class="info-row"><span class="info-label">Fuel Induction</span><span class="info-value">Turbocharged</span></div>
            <div class="info-row"><span class="info-label">Fuel Type</span><span class="info-value">Diesel</span></div>
            <div class="info-row"><span class="info-label">Valves</span><span class="info-value">16 Valves</span></div>
            <div class="info-row"><span class="info-label">Max Horsepower</span><span class="info-value">140 HP (approx. 103 kW)</span></div>
            <div class="info-row"><span class="info-label">Total Max Torque</span><span class="info-value">340 Nm</span></div>
            <div class="info-row"><span class="info-label">Transmission</span><span class="info-value">Manual</span></div>
        </div>
    </div>

    <!-- PAGE 10: Safety Features -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-shield-heart"></i><h2>Safety Features</h2></div>
        <div class="three-col">
            <div class="info-row"><span class="info-label">Front Airbags</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Side Airbags</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Side Curtain Airbags</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">ABS</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Braking Assist</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Electronic Brakeforce Distribution</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Active Head Restraints</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Child Safety Door Locks</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Child Seat Anchors</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Crumple Zones</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Emergency Interior Trunk Release</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
        </div>
    </div>

    <!-- PAGE 11: Security Features -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-lock"></i><h2>Security Features</h2></div>
        <div class="two-col">
            <div class="info-row"><span class="info-label">Hill Holder Control</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Stability Control</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Traction Control</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Anti-Theft System</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Power Door Locks</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Front Seatbelts</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Rear Seatbelts</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Seatbelt Pretensioners</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
            <div class="info-row"><span class="info-label">Seatbelt Warning Sensor</span><span class="info-value"><span class="badge-premium badge-equipped">Equipped</span></span></div>
        </div>
        
        <!-- Black/White Graphic Blocks (Page 11 as per your audit) -->
        <div style="display: flex; gap: 15px; margin-top: 28px; justify-content: center;">
            <div style="width: 80px; height: 8px; background: #1A1A2E; border-radius: 4px;"></div>
            <div style="width: 80px; height: 8px; background: #6C63FF; border-radius: 4px;"></div>
            <div style="width: 80px; height: 8px; background: #E0E0E0; border-radius: 4px;"></div>
        </div>
    </div>

    <!-- PAGE 12: Fuel Efficiency -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-gas-pump"></i><h2>Fuel Efficiency (EPA MPG Estimates)</h2></div>
        <div class="two-col">
            <div class="info-row"><span class="info-label">Fuel Grade</span><span class="info-value">Diesel</span></div>
            <div class="info-row"><span class="info-label">City Economy</span><span class="info-value">Estimated 35 MPG</span></div>
            <div class="info-row"><span class="info-label">Highway Economy</span><span class="info-value">Estimated 44 MPG</span></div>
            <div class="info-row"><span class="info-label">Combined Economy</span><span class="info-value">Estimated 40 MPG</span></div>
        </div>
    </div>
<br>
    <!-- Auditing Summary & Conclusion -->
    <div class="content-block">
        <div class="block-title"><i class="fas fa-clipboard-list"></i><h2>Auditing Summary & Conclusion</h2></div>
        <div style="background: linear-gradient(135deg, #F8F9FF, #FFFFFF); border-radius: 20px; padding: 24px;">
            <p style="margin-bottom: 16px; line-height: 1.6; color: #1A1A2E;">
                <i class="fas fa-check-circle" style="color: #28A745; margin-right: 8px;"></i>
                <strong>Clean Bill of Health</strong> — This vehicle has covered <strong>190,000 miles</strong>, which is significant mileage. 
                However, despite the high mileage, there are <strong>no accident, salvage, theft, flood damage, or odometer tampering</strong> negative records found.
            </p>
            <p style="line-height: 1.6; color: #1A1A2E;">
                <i class="fas fa-pound-sign" style="color: #6C63FF; margin-right: 8px;"></i>
                Market value is estimated at <strong>£9,000</strong> with a <strong>current and valid MOT</strong>.
            </p>
        </div>
    </div>

    <!-- Disclaimer -->
    <div class="disclaimer-premium">
        <i class="fas fa-info-circle"></i> Disclaimer: The information presented in this report may have changed significantly since the date of this inquiry. This report is for informational purposes only. VinUnified recommends an independent inspection before purchase. VinUnified is not liable for any decisions made based on this report.
    </div>

    <!-- Footer -->
    <div class="footer-premium">
        <div class="footer-logo"><img src="https://vinunified.store/assets/images/vinunified-white.png" alt="VinUnified"></div>
        <div class="footer-text"><i class="fas fa-globe"></i> One VIN. Global History.</div>
        <div class="footer-badge"><i class="fas fa-lock"></i> Secured by DocuKit</div>
    </div>

</div>

<script>
    document.getElementById('savePdfBtn').addEventListener('click', function() {
        const element = document.getElementById('reportContainer');
        const opt = {
            margin: [0.5, 0.5, 0.5, 0.5], // margins in inches
            filename: 'VinUnified_Vehicle_History_Report.pdf',
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true, logging: false },
            jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
        };
        html2pdf().set(opt).from(element).save();
    });
</script>

</body>
</html>