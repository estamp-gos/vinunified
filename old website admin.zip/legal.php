<?php
// legal.php - Privacy Policy + Terms + Refund (One Page)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legal - VinUnified</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .legal-container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
        }
        .legal-section {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        }
        .legal-section h2 {
            color: #6C63FF;
            margin-bottom: 20px;
            border-bottom: 2px solid #E8E6FF;
            padding-bottom: 10px;
        }
        .legal-section h3 {
            color: #03045E;
            margin: 20px 0 10px;
        }
        .legal-section p, .legal-section li {
            color: #6C757D;
            line-height: 1.6;
        }
        .legal-section ul {
            padding-left: 20px;
            margin: 15px 0;
        }
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: #6C63FF;
            color: white;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            margin-bottom: 20px;
        }
    </style>
</head>
<body style="background: #F8F9FF;">
    <div class="legal-container">
        <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Home</a>
        
        <!-- Privacy Policy -->
        <div class="legal-section">
            <h2>Privacy Policy</h2>
            <p><strong>Last Updated:</strong> January 1, 2026</p>
            <p>At VinUnified, we value your privacy. This policy explains how we collect, use, and protect your information.</p>
            
            <h3>Information We Collect</h3>
            <ul>
                <li>Full Name</li>
                <li>Email Address</li>
                <li>Phone Number</li>
                <li>VIN Number or License Plate</li>
                <li>Vehicle Type</li>
                <li>IP Address (for security)</li>
            </ul>
            
            <h3>How We Use Your Information</h3>
            <ul>
                <li>To generate and deliver vehicle history reports</li>
                <li>To process payments through our partner Docukit</li>
                <li>To communicate with you about your order</li>
                <li>To prevent fraud and ensure security</li>
            </ul>
            
            <h3>Data Retention</h3>
            <p>Your data is automatically deleted after 30 days. We do not share, sell, or market your personal information.</p>
            
            <h3>Third-Party Services</h3>
            <p>Payments are processed securely by Docukit. We do not store payment information on our servers.</p>
        </div>
        
        <!-- Terms & Conditions -->
        <div class="legal-section">
            <h2>Terms & Conditions</h2>
            <p><strong>Last Updated:</strong> January 1, 2026</p>
            <p>By using VinUnified.store, you agree to these Terms & Conditions.</p>
            
            <h3>Service Description</h3>
            <p>VinUnified provides vehicle history reports based on worldwide digital data available from public sources. Reports include accident history, title records, odometer readings, recalls, and market value where available.</p>
            
            <h3>Disclaimer</h3>
            <p>While we strive for accuracy, we do not guarantee 100% completeness. Reports are generated from available data sources. We recommend using this report as one factor in your decision-making process.</p>
            
            <h3>Limitation of Liability</h3>
            <p>VinUnified shall not be liable for any indirect, incidental, or consequential damages arising from the use of our service. Our total liability shall not exceed the amount paid for the report.</p>
        </div>
        
        <!-- Refund Policy -->
        <div class="legal-section">
            <h2>Refund Policy</h2>
            <p><strong>Last Updated:</strong> January 1, 2026</p>
            
            <h3>14-Day Refund Window</h3>
            <p>We offer a 14-day refund policy from the date of purchase under the following conditions:</p>
            <ul>
                <li>If you are not satisfied with your report, contact us first</li>
                <li>We will send you an updated report for free</li>
                <li>If you are still not satisfied, we will issue a full refund</li>
            </ul>
            
            <h3>No Chargebacks Without Contact</h3>
            <p><strong>⚠️ Important:</strong> Please do not file a chargeback without contacting us first. If you file a chargeback without prior contact, we reserve the right to dispute it and take legal action. We are always here to help resolve your issue.</p>
            
            <h3>How to Request a Refund</h3>
            <p>Email us at <strong>support@vinunified.store</strong> with your order details and reason for refund. We will respond within 24-48 hours.</p>
            
            <h3>Non-Refundable Situations</h3>
            <ul>
                <li>If the report contains data (even if negative as expected)</li>
                <li>If you entered the wrong VIN (we generate report for the VIN provided)</li>
                <li>After 14 days from purchase</li>
            </ul>
        </div>
        
        <div style="text-align: center; margin-top: 30px;">
            <a href="index.php" class="btn-sample" style="display: inline-flex;">← Back to Home</a>
        </div>
    </div>
</body>
</html>