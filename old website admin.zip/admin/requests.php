<?php
// admin/requests.php - Admin Dashboard to View All Form Submissions
session_start();

require_once '../inc/database.php';

// Pagination variables
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20; // Records per page
$offset = ($page - 1) * $limit;

// Filter by status (optional)
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';

// Get total records count
$pdo = getDBConnection();
if (!$pdo) {
    die("Database connection failed");
}

// Convert limit and offset to integers and ensure they're positive
$limit = max(1, $limit);
$offset = max(0, $offset);

if ($statusFilter && $statusFilter !== '') {
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM vin_requests WHERE status = :status");
    $countStmt->execute(['status' => $statusFilter]);
} else {
    $countStmt = $pdo->query("SELECT COUNT(*) FROM vin_requests");
}
$totalRecords = (int)$countStmt->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

// Fetch records with pagination - FIXED: Using proper LIMIT syntax
if ($statusFilter && $statusFilter !== '') {
    $stmt = $pdo->prepare("SELECT * FROM vin_requests WHERE status = :status ORDER BY id DESC LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':status', $statusFilter, PDO::PARAM_STR);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
} else {
    $stmt = $pdo->prepare("SELECT * FROM vin_requests ORDER BY id DESC LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
}
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - VinUnified Requests</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: #f5f7fb;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        .header {
            background: linear-gradient(135deg, #6C63FF, #00B4D8);
            color: white;
            padding: 25px;
            border-radius: 20px;
            margin-bottom: 25px;
        }
        .header h1 { font-size: 28px; margin-bottom: 5px; }
        .header p { opacity: 0.9; }
        .stats {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 16px;
            flex: 1;
            min-width: 150px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-left: 4px solid #6C63FF;
        }
        .stat-card h3 { font-size: 14px; color: #6C757D; margin-bottom: 8px; }
        .stat-card .number { font-size: 32px; font-weight: 700; color: #03045E; }
        .filters {
            background: white;
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filters select, .filters input {
            padding: 8px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }
        .filters button {
            background: #6C63FF;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 8px;
            cursor: pointer;
        }
        .table-container {
            background: white;
            border-radius: 16px;
            overflow-x: auto;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background: #f8f9ff;
            color: #03045E;
            font-weight: 600;
        }
        .status {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-pending { background: #FFF3CD; color: #856404; }
        .status-paid { background: #D4EDDA; color: #155724; }
        .status-delivered { background: #CCE5FF; color: #004085; }
        .status-refunded { background: #F8D7DA; color: #721C24; }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 25px;
            flex-wrap: wrap;
        }
        .pagination a, .pagination span {
            padding: 8px 15px;
            background: white;
            border-radius: 8px;
            text-decoration: none;
            color: #6C63FF;
            border: 1px solid #ddd;
        }
        .pagination .active {
            background: #6C63FF;
            color: white;
            border-color: #6C63FF;
        }
        @media (max-width: 768px) {
            th, td { padding: 10px; font-size: 12px; }
            .stat-card .number { font-size: 24px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📋 VinUnified Admin Dashboard</h1>
            <p>Manage and view all vehicle history requests</p>
        </div>

        <?php
        // Calculate statistics
        $pendingStmt = $pdo->query("SELECT COUNT(*) FROM vin_requests WHERE status = 'pending'");
        $pending = $pendingStmt ? $pendingStmt->fetchColumn() : 0;
        
        $paidStmt = $pdo->query("SELECT COUNT(*) FROM vin_requests WHERE status = 'paid'");
        $paid = $paidStmt ? $paidStmt->fetchColumn() : 0;
        
        $totalStmt = $pdo->query("SELECT COUNT(*) FROM vin_requests");
        $total = $totalStmt ? $totalStmt->fetchColumn() : 0;
        ?>

        <div class="stats">
            <div class="stat-card"><h3>Total Requests</h3><div class="number"><?php echo $total; ?></div></div>
            <div class="stat-card"><h3>Pending Payment</h3><div class="number"><?php echo $pending; ?></div></div>
            <div class="stat-card"><h3>Paid</h3><div class="number"><?php echo $paid; ?></div></div>
        </div>

        <div class="filters">
            <form method="GET" style="display: flex; gap: 15px; flex-wrap: wrap;">
                <select name="status">
                    <option value="">All Status</option>
                    <option value="pending" <?php echo $statusFilter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="paid" <?php echo $statusFilter == 'paid' ? 'selected' : ''; ?>>Paid</option>
                    <option value="delivered" <?php echo $statusFilter == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                    <option value="refunded" <?php echo $statusFilter == 'refunded' ? 'selected' : ''; ?>>Refunded</option>
                </select>
                <button type="submit">Filter</button>
                <a href="?page=1" style="background:#6C757D; color:white; padding:8px 20px; border-radius:8px; text-decoration:none;">Reset</a>
            </form>
        </div>

        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>VIN</th>
                        <th>Vehicle</th>
                        <th>Package</th>
                        <th>Status</th>
                        <th>IP Address</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($requests)): ?>
                        <tr><td colspan="11" style="text-align:center;">No records found</td></tr>
                    <?php else: ?>
                        <?php foreach ($requests as $req): ?>
                        <tr>
                            <td><?php echo $req['id']; ?></td>
                            <td><?php echo htmlspecialchars($req['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($req['email']); ?></td>
                            <td><?php echo htmlspecialchars($req['phone']); ?></td>
                            <td><code><?php echo htmlspecialchars($req['vin'] ?: '—'); ?></code></td>
                            <td><?php echo htmlspecialchars($req['vehicle_type']); ?></td>
                            <td><span class="status"><?php echo ucfirst($req['package']); ?></span></td>
                            <td><span class="status status-<?php echo $req['status']; ?>"><?php echo ucfirst($req['status']); ?></span></td>
                            <td><?php echo $req['ip_address']; ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($req['created_at'])); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="id" value="<?php echo $req['id']; ?>">
                                    <select name="new_status" onchange="this.form.submit()" style="padding:4px; font-size:12px;">
                                        <option value="pending" <?php echo $req['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="paid" <?php echo $req['status'] == 'paid' ? 'selected' : ''; ?>>Paid</option>
                                        <option value="delivered" <?php echo $req['status'] == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                        <option value="refunded" <?php echo $req['status'] == 'refunded' ? 'selected' : ''; ?>>Refunded</option>
                                    </select>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page-1; ?>&status=<?php echo urlencode($statusFilter); ?>">« Previous</a>
            <?php endif; ?>
            
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="active"><?php echo $i; ?></span>
                <?php else: ?>
                    <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($statusFilter); ?>"><?php echo $i; ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?php echo $page+1; ?>&status=<?php echo urlencode($statusFilter); ?>">Next »</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <?php
    // Handle status update
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_POST['new_status'])) {
        $id = (int)$_POST['id'];
        $newStatus = $_POST['new_status'];
        $updateStmt = $pdo->prepare("UPDATE vin_requests SET status = :status WHERE id = :id");
        $updateStmt->execute(['status' => $newStatus, 'id' => $id]);
        // Redirect to refresh the page
        header('Location: ' . $_SERVER['PHP_SELF'] . '?page=' . $page . '&status=' . urlencode($statusFilter));
        exit;
    }
    ?>
</body>
</html>