<?php
// admin/dashboard.php - WITH TOKEN EXTEND & COPY LINK FEATURE
require_once 'inc/admin-auth.php';
requireAdminLogin();
require_once '../inc/database.php';

$pdo = getDBConnection();
if (!$pdo) {
    die("Database connection failed");
}

// Handle status update for vin_requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_POST['new_status'])) {
    $id = (int)$_POST['id'];
    $newStatus = $_POST['new_status'];
    $updateStmt = $pdo->prepare("UPDATE vin_requests SET status = :status WHERE id = :id");
    $updateStmt->execute(['status' => $newStatus, 'id' => $id]);
    header('Location: ' . $_SERVER['PHP_SELF'] . '?page=' . ($_GET['page'] ?? 1) . '&table=' . ($_GET['table'] ?? 'requests') . '&status=' . urlencode($_GET['status'] ?? '') . '&search=' . urlencode($_GET['search'] ?? ''));
    exit;
}

// Handle token extend (EXTEND TO 12 HOURS)
if (isset($_GET['extend_token']) && isset($_GET['token_id'])) {
    $tokenId = (int)$_GET['token_id'];
    $newExpiry = date('Y-m-d H:i:s', strtotime('+12 hours'));
    $updateStmt = $pdo->prepare("UPDATE payment_tokens SET expiry_time = :expiry, used = 0 WHERE id = :id");
    $updateStmt->execute(['expiry' => $newExpiry, 'id' => $tokenId]);
    
    // Redirect back
    header('Location: ' . $_SERVER['PHP_SELF'] . '?page=' . ($_GET['page'] ?? 1) . '&table=tokens&msg=token_extended');
    exit;
}

// Handle export
if (isset($_GET['export'])) {
    $exportTable = $_GET['export'];
    if ($exportTable === 'requests') {
        $stmt = $pdo->query("SELECT * FROM vin_requests ORDER BY id DESC");
        $data = $stmt->fetchAll();
        $filename = "vin_requests_" . date('Y-m-d') . ".csv";
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Full Name', 'Email', 'Phone', 'VIN', 'License Plate', 'Vehicle Type', 'Package', 'Status', 'IP Address', 'Created At']);
        foreach ($data as $row) {
            fputcsv($output, [$row['id'], $row['full_name'], $row['email'], $row['phone'], $row['vin'], $row['license_plate'], $row['vehicle_type'], $row['package'], $row['status'], $row['ip_address'], $row['created_at']]);
        }
        fclose($output);
        exit;
    } elseif ($exportTable === 'tokens') {
        $stmt = $pdo->query("SELECT * FROM payment_tokens ORDER BY id DESC");
        $data = $stmt->fetchAll();
        $filename = "payment_tokens_" . date('Y-m-d') . ".csv";
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Token', 'Customer Name', 'Customer Email', 'Expiry Time', 'Used', 'Created At']);
        foreach ($data as $row) {
            $formData = json_decode($row['form_data'], true);
            $customerName = $formData['full_name'] ?? 'N/A';
            $customerEmail = $formData['email'] ?? 'N/A';
            fputcsv($output, [$row['id'], $row['token'], $customerName, $customerEmail, $row['expiry_time'], $row['used'] ? 'Yes' : 'No', $row['created_at']]);
        }
        fclose($output);
        exit;
    }
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Filters
$statusFilter = isset($_GET['status']) ? $_GET['status'] : '';
$searchFilter = isset($_GET['search']) ? trim($_GET['search']) : '';
$tableFilter = isset($_GET['table']) ? $_GET['table'] : 'requests';

// Count records
if ($tableFilter === 'tokens') {
    $countSql = "SELECT COUNT(*) FROM payment_tokens";
    $params = [];
    if ($statusFilter === 'valid') {
        $countSql .= " WHERE expiry_time > NOW() AND used = 0";
    } elseif ($statusFilter === 'expired') {
        $countSql .= " WHERE expiry_time <= NOW()";
    } elseif ($statusFilter === 'used') {
        $countSql .= " WHERE used = 1";
    }
    if ($searchFilter) {
        $countSql .= (strpos($countSql, 'WHERE') === false ? " WHERE" : " AND") . " (token LIKE :search OR form_data LIKE :search)";
        $params[':search'] = "%$searchFilter%";
    }
    $countStmt = $pdo->prepare($countSql);
    $countStmt->execute($params);
    $totalRecords = $countStmt->fetchColumn();
    
    $sql = "SELECT * FROM payment_tokens";
    if ($statusFilter === 'valid') {
        $sql .= " WHERE expiry_time > NOW() AND used = 0";
    } elseif ($statusFilter === 'expired') {
        $sql .= " WHERE expiry_time <= NOW()";
    } elseif ($statusFilter === 'used') {
        $sql .= " WHERE used = 1";
    }
    if ($searchFilter) {
        $sql .= (strpos($sql, 'WHERE') === false ? " WHERE" : " AND") . " (token LIKE :search OR form_data LIKE :search)";
        $params[':search'] = "%$searchFilter%";
    }
    $sql .= " ORDER BY id DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    if ($searchFilter) {
        $stmt->bindParam(':search', $params[':search']);
    }
    $stmt->execute();
    $records = $stmt->fetchAll();
} else {
    $sql = "SELECT * FROM vin_requests";
    $params = [];
    if ($statusFilter && $statusFilter !== '') {
        $sql .= " WHERE status = :status";
        $params[':status'] = $statusFilter;
    }
    if ($searchFilter) {
        $sql .= (strpos($sql, 'WHERE') === false ? " WHERE" : " AND") . " (full_name LIKE :search OR email LIKE :search OR vin LIKE :search)";
        $params[':search'] = "%$searchFilter%";
    }
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM vin_requests" . (strpos($sql, 'WHERE') !== false ? substr($sql, strpos($sql, 'WHERE')) : ''));
    foreach ($params as $key => $val) {
        $countStmt->bindValue($key, $val);
    }
    $countStmt->execute();
    $totalRecords = $countStmt->fetchColumn();
    
    $sql .= " ORDER BY id DESC LIMIT :limit OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    foreach ($params as $key => $val) {
        $stmt->bindValue($key, $val);
    }
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $records = $stmt->fetchAll();
}

$totalPages = ceil($totalRecords / $limit);

// Stats
$totalRequests = $pdo->query("SELECT COUNT(*) FROM vin_requests")->fetchColumn();
$pendingRequests = $pdo->query("SELECT COUNT(*) FROM vin_requests WHERE status = 'pending'")->fetchColumn();
$paidRequests = $pdo->query("SELECT COUNT(*) FROM vin_requests WHERE status = 'paid'")->fetchColumn();
$totalTokens = $pdo->query("SELECT COUNT(*) FROM payment_tokens")->fetchColumn();
$validTokens = $pdo->query("SELECT COUNT(*) FROM payment_tokens WHERE expiry_time > NOW() AND used = 0")->fetchColumn();

// Success message
$successMsg = '';
if (isset($_GET['msg']) && $_GET['msg'] === 'token_extended') {
    $successMsg = '<div style="background: #D4EDDA; color: #155724; padding: 12px 20px; border-radius: 12px; margin-bottom: 20px;"><i class="fas fa-check-circle"></i> Token extended successfully for next 12 hours!</div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="VinUnified Admin">
    <link rel="manifest" href="manifest.json">
    <title>Admin Dashboard - VinUnified</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f5f7fb; overflow-x: auto; }
        
        /* SIDEBAR */
        .admin-container { display: flex; min-height: 100vh; }
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #03045E, #1a1a6e);
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: transform 0.3s ease;
            z-index: 1000;
            transform: translateX(0);
        }
        .sidebar.collapsed { transform: translateX(-280px); }
        .sidebar-header { padding: 25px 20px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar-header img { height: 50px; margin-bottom: 15px; }
        .sidebar-header h3 { font-size: 18px; }
        .sidebar-nav { padding: 20px 0; }
        .nav-item {
            padding: 12px 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-item:hover { background: rgba(255,255,255,0.1); color: white; }
        .nav-item.active { background: rgba(108,99,255,0.3); border-left-color: #6C63FF; color: white; }
        .nav-item i { width: 22px; }
        .logout-btn { margin-top: 30px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 20px; color: #ff6b6b; }
        .logout-btn:hover { background: rgba(255,107,107,0.1); color: #ff6b6b; }
        
        /* MAIN CONTENT */
        .main-content { flex: 1; margin-left: 280px; padding: 20px; min-width: 0; transition: margin-left 0.3s ease; }
        .main-content.expanded { margin-left: 0; }
        
        /* TOP BAR */
        .top-bar {
            background: white;
            border-radius: 16px;
            padding: 15px 25px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .top-bar-left { display: flex; align-items: center; gap: 15px; }
        .sidebar-toggle {
            background: #6C63FF;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 18px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .sidebar-toggle:hover { background: #4A42D1; }
        .top-bar h2 { color: #03045E; font-size: 22px; }
        .btn-group { display: flex; gap: 10px; flex-wrap: wrap; }
        .refresh-btn, .export-btn, .install-btn {
            background: #6C63FF;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            text-decoration: none;
        }
        .export-btn { background: #28A745; }
        .install-btn { background: #FF9800; }
        .refresh-btn:hover { background: #4A42D1; }
        .export-btn:hover { background: #218838; }
        .install-btn:hover { background: #F57C00; }
        
        /* STATS */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 18px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            border-left: 4px solid #6C63FF;
        }
        .stat-card h4 { color: #6C757D; font-size: 13px; margin-bottom: 8px; }
        .stat-card .number { font-size: 28px; font-weight: 700; color: #03045E; }
        
        /* FILTERS */
        .filters-bar {
            background: white;
            border-radius: 16px;
            padding: 15px 20px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filters-bar select, .filters-bar input {
            padding: 8px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
        }
        .filters-bar button { background: #6C63FF; color: white; border: none; padding: 8px 20px; border-radius: 8px; cursor: pointer; }
        .reset-btn { background: #6C757D !important; }
        
        /* TABLE */
        .table-container {
            background: white;
            border-radius: 16px;
            overflow-x: auto;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            -webkit-overflow-scrolling: touch;
        }
        table { width: 100%; border-collapse: collapse; min-width: 800px; }
        th, td { padding: 14px 16px; text-align: left; border-bottom: 1px solid #eee; white-space: nowrap; }
        th { background: #f8f9ff; color: #03045E; font-weight: 600; position: sticky; top: 0; }
        
        .status {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-pending { background: #FFF3CD; color: #856404; }
        .status-paid { background: #D4EDDA; color: #155724; }
        .status-delivered { background: #CCE5FF; color: #004085; }
        .status-refunded { background: #F8D7DA; color: #721C24; }
        .token-valid { color: #28a745; font-weight: 500; }
        .token-expired { color: #dc3545; font-weight: 500; }
        .token-used { color: #ffc107; font-weight: 500; }
        
        .status-select { padding: 6px 10px; border-radius: 8px; border: 1px solid #ddd; font-size: 13px; cursor: pointer; }
        
        /* Action Buttons */
        .action-btn {
            background: #6C63FF;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 12px;
            margin-right: 5px;
            text-decoration: none;
            display: inline-block;
        }
        .action-btn.copy-btn { background: #17a2b8; }
        .action-btn.extend-btn { background: #28A745; }
        .action-btn:hover { opacity: 0.9; }
        
        /* PAGINATION */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 25px;
            flex-wrap: wrap;
        }
        .pagination a, .pagination span {
            padding: 8px 14px;
            background: white;
            border-radius: 8px;
            text-decoration: none;
            color: #6C63FF;
            border: 1px solid #ddd;
        }
        .pagination .active { background: #6C63FF; color: white; border-color: #6C63FF; }
        
        /* MOBILE */
        .mobile-menu-toggle {
            display: none;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: #6C63FF;
            color: white;
            border: none;
            padding: 12px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 18px;
        }
        
        @media (max-width: 768px) {
            .mobile-menu-toggle { display: block; }
            .sidebar { transform: translateX(-100%); }
            .sidebar.mobile-open { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 70px 15px 20px; }
            .top-bar { flex-direction: column; }
            .top-bar-left { width: 100%; justify-content: space-between; }
            .sidebar-toggle { display: none; }
            .btn-group { width: 100%; justify-content: center; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .filters-bar { flex-direction: column; }
            .filters-bar select, .filters-bar input, .filters-bar button { width: 100%; }
        }
        
        @media (max-width: 480px) { .stats-grid { grid-template-columns: 1fr; } }
        
        .install-prompt {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #03045E;
            color: white;
            padding: 15px 20px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            z-index: 1002;
            align-items: center;
            gap: 15px;
            max-width: 300px;
        }
        .install-prompt.show { display: flex; }
        .install-prompt button { background: #6C63FF; color: white; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; }
        .install-prompt .close-prompt { background: transparent; color: white; font-size: 18px; padding: 5px; }
    </style>
</head>
<body>
    <button class="mobile-menu-toggle" id="mobileMenuToggle"><i class="fas fa-bars"></i> Menu</button>
    
    <div class="admin-container">
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <img src="https://vinunified.store/assets/images/vinunified-nav.png" alt="VinUnified">
                <h3>Admin Panel</h3>
            </div>
            <div class="sidebar-nav">
                <a href="?table=requests" class="nav-item <?php echo $tableFilter === 'requests' ? 'active' : ''; ?>">
                    <i class="fas fa-file-alt"></i><span>Vin Requests</span>
                </a>
                <a href="?table=tokens" class="nav-item <?php echo $tableFilter === 'tokens' ? 'active' : ''; ?>">
                    <i class="fas fa-key"></i><span>Payment Tokens</span>
                </a>
                <a href="logout.php" class="nav-item logout-btn">
                    <i class="fas fa-sign-out-alt"></i><span>Logout</span>
                </a>
            </div>
        </aside>
        
        <main class="main-content" id="mainContent">
            <div class="top-bar">
                <div class="top-bar-left">
                    <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-chevron-left"></i> Hide Menu</button>
                    <h2><i class="fas fa-chart-line"></i> <?php echo $tableFilter === 'tokens' ? 'Payment Tokens' : 'Vehicle History Requests'; ?></h2>
                </div>
                <div class="btn-group">
                    <button class="refresh-btn" onclick="location.reload();"><i class="fas fa-sync-alt"></i> Refresh</button>
                    <button class="install-btn" id="installBtn"><i class="fas fa-download"></i> Install App</button>
                    <a href="?export=<?php echo $tableFilter; ?>" class="export-btn"><i class="fas fa-file-csv"></i> Export CSV</a>
                </div>
            </div>
            
            <?php echo $successMsg; ?>
            
            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card"><h4>Total Requests</h4><div class="number"><?php echo $totalRequests; ?></div></div>
                <div class="stat-card"><h4>Pending Payment</h4><div class="number"><?php echo $pendingRequests; ?></div></div>
                <div class="stat-card"><h4>Paid</h4><div class="number"><?php echo $paidRequests; ?></div></div>
                <div class="stat-card"><h4>Total Tokens</h4><div class="number"><?php echo $totalTokens; ?></div></div>
                <div class="stat-card"><h4>Valid Tokens</h4><div class="number"><?php echo $validTokens; ?></div></div>
            </div>
            
            <!-- Filters -->
            <div class="filters-bar">
                <form method="GET" style="display: flex; gap: 10px; flex-wrap: wrap; width: 100%;">
                    <input type="hidden" name="table" value="<?php echo $tableFilter; ?>">
                    <select name="status">
                        <option value="">All Status</option>
                        <?php if ($tableFilter === 'tokens'): ?>
                            <option value="valid" <?php echo $statusFilter == 'valid' ? 'selected' : ''; ?>>Valid</option>
                            <option value="expired" <?php echo $statusFilter == 'expired' ? 'selected' : ''; ?>>Expired</option>
                            <option value="used" <?php echo $statusFilter == 'used' ? 'selected' : ''; ?>>Used</option>
                        <?php else: ?>
                            <option value="pending" <?php echo $statusFilter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="paid" <?php echo $statusFilter == 'paid' ? 'selected' : ''; ?>>Paid</option>
                            <option value="delivered" <?php echo $statusFilter == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                            <option value="refunded" <?php echo $statusFilter == 'refunded' ? 'selected' : ''; ?>>Refunded</option>
                        <?php endif; ?>
                    </select>
                    <input type="text" name="search" placeholder="Search..." value="<?php echo htmlspecialchars($searchFilter); ?>">
                    <button type="submit"><i class="fas fa-filter"></i> Apply</button>
                    <a href="?table=<?php echo $tableFilter; ?>" class="reset-btn" style="background:#6C757D; color:white; padding:8px 20px; border-radius:8px; text-decoration:none;">Reset</a>
                </form>
            </div>
            
            <!-- Table -->
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <?php if ($tableFilter === 'tokens'): ?>
                                <th>ID</th><th>Customer</th><th>Token</th><th>Expiry Time</th><th>Status</th><th>Created</th><th>Actions</th>
                            <?php else: ?>
                                <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>VIN</th><th>Plate</th><th>Vehicle</th><th>Package</th><th>Status</th><th>IP</th><th>Date</th><th>Action</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($records)): ?>
                            <tr><td colspan="12" style="text-align:center;">No records found</td></tr>
                        <?php else: ?>
                            <?php foreach ($records as $row): ?>
                                <?php if ($tableFilter === 'tokens'): 
                                    $formData = json_decode($row['form_data'], true);
                                    $customerName = $formData['full_name'] ?? 'N/A';
                                    $customerEmail = $formData['email'] ?? 'N/A';
                                    $token = $row['token'];
                                    $paymentLink = "https://payments.docukit.site/index.php?token=" . $token;
                                    $now = new DateTime();
                                    $expiry = new DateTime($row['expiry_time']);
                                    $isExpired = ($expiry < $now);
                                    $isUsed = ($row['used'] == 1);
                                ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($customerName); ?></strong><br>
                                        <small><?php echo htmlspecialchars($customerEmail); ?></small>
                                    </td>
                                    <td><code style="font-size:10px;"><?php echo substr($token, 0, 40); ?>...</code></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($row['expiry_time'])); ?>
                                        <?php if ($isExpired): ?>
                                            <br><small style="color:red;">(Expired)</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($isExpired): ?>
                                            <span class="token-expired">Expired</span>
                                        <?php elseif ($isUsed): ?>
                                            <span class="token-used">Used</span>
                                        <?php else: ?>
                                            <span class="token-valid">Valid</span>
                                        <?php endif; ?>
                                     </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <button class="action-btn copy-btn" onclick="copyToClipboard('<?php echo $paymentLink; ?>')"><i class="fas fa-copy"></i> Copy Link</button>
                                        <?php if ($isExpired): ?>
                                            <a href="?extend_token=1&token_id=<?php echo $row['id']; ?>&page=<?php echo $page; ?>&table=tokens" class="action-btn extend-btn" onclick="return confirm('Extend this token for next 12 hours?')"><i class="fas fa-clock"></i> Extend 12h</a>
                                        <?php endif; ?>
                                     </td>
                                </tr>
                                <?php else: ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><code><?php echo htmlspecialchars($row['vin'] ?: '—'); ?></code></td>
                                    <td><code><?php echo htmlspecialchars($row['license_plate'] ?: '—'); ?></code></td>
                                    <td><?php echo htmlspecialchars($row['vehicle_type']); ?></td>
                                    <td><span class="status"><?php echo ucfirst($row['package']); ?></span></td>
                                    <td><span class="status status-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></td>
                                    <td><?php echo $row['ip_address']; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                            <select name="new_status" class="status-select" onchange="this.form.submit()">
                                                <option value="pending" <?php echo $row['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                <option value="paid" <?php echo $row['status'] == 'paid' ? 'selected' : ''; ?>>Paid</option>
                                                <option value="delivered" <?php echo $row['status'] == 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                                <option value="refunded" <?php echo $row['status'] == 'refunded' ? 'selected' : ''; ?>>Refunded</option>
                                            </select>
                                        </form>
                                     </td>
                                </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page-1; ?>&table=<?php echo $tableFilter; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($searchFilter); ?>">« Prev</a>
                <?php endif; ?>
                <?php for ($i = max(1, $page-2); $i <= min($totalPages, $page+2); $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="active"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $i; ?>&table=<?php echo $tableFilter; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($searchFilter); ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?php echo $page+1; ?>&table=<?php echo $tableFilter; ?>&status=<?php echo urlencode($statusFilter); ?>&search=<?php echo urlencode($searchFilter); ?>">Next »</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </main>
    </div>
    
    <!-- Install Prompt -->
    <div class="install-prompt" id="installPrompt">
        <i class="fas fa-mobile-alt" style="font-size: 24px;"></i>
        <span>Install VinUnified Admin as App</span>
        <button id="doInstall">Install</button>
        <button class="close-prompt" id="closePrompt">✕</button>
    </div>
    
    <script>
        // Copy to clipboard function
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Payment link copied to clipboard!\n\n' + text);
            }, function() {
                alert('Failed to copy link. Please copy manually.');
            });
        }
        
        // Sidebar Toggle
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        const sidebarToggle = document.getElementById('sidebarToggle');
        let sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
        
        function toggleSidebar() {
            sidebarCollapsed = !sidebarCollapsed;
            localStorage.setItem('sidebarCollapsed', sidebarCollapsed);
            if (sidebarCollapsed) {
                sidebar.classList.add('collapsed');
                mainContent.classList.add('expanded');
                sidebarToggle.innerHTML = '<i class="fas fa-chevron-right"></i> Show Menu';
            } else {
                sidebar.classList.remove('collapsed');
                mainContent.classList.remove('expanded');
                sidebarToggle.innerHTML = '<i class="fas fa-chevron-left"></i> Hide Menu';
            }
        }
        
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', toggleSidebar);
            if (sidebarCollapsed) {
                sidebar.classList.add('collapsed');
                mainContent.classList.add('expanded');
                sidebarToggle.innerHTML = '<i class="fas fa-chevron-right"></i> Show Menu';
            }
        }
        
        // Mobile sidebar
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        if (mobileMenuToggle) {
            mobileMenuToggle.addEventListener('click', function() {
                sidebar.classList.toggle('mobile-open');
            });
        }
        
        document.addEventListener('click', function(e) {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(e.target) && !mobileMenuToggle.contains(e.target)) {
                    sidebar.classList.remove('mobile-open');
                }
            }
        });
        
        // PWA Install
        let deferredPrompt;
        const installBtn = document.getElementById('installBtn');
        const installPrompt = document.getElementById('installPrompt');
        const doInstall = document.getElementById('doInstall');
        const closePrompt = document.getElementById('closePrompt');
        
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            installPrompt.classList.add('show');
        });
        
        if (doInstall) {
            doInstall.addEventListener('click', () => {
                if (deferredPrompt) {
                    deferredPrompt.prompt();
                    deferredPrompt.userChoice.then((choiceResult) => {
                        if (choiceResult.outcome === 'accepted') {
                            console.log('User accepted the install prompt');
                        }
                        deferredPrompt = null;
                        installPrompt.classList.remove('show');
                    });
                }
            });
        }
        
        if (closePrompt) {
            closePrompt.addEventListener('click', () => {
                installPrompt.classList.remove('show');
            });
        }
        
        if (installBtn) {
            installBtn.addEventListener('click', () => {
                if (deferredPrompt) {
                    deferredPrompt.prompt();
                    deferredPrompt.userChoice.then((choiceResult) => {
                        if (choiceResult.outcome === 'accepted') {
                            console.log('User accepted the install prompt');
                        }
                        deferredPrompt = null;
                    });
                } else {
                    alert('To install as app, use Chrome browser and click the install icon in the address bar, or add to home screen from browser menu.');
                }
            });
        }
    </script>
</body>
</html>