<?php
// admin/inc/admin-auth.php
session_start();

// Fixed admin credentials
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'VinUnified@2026');

function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function requireAdminLogin() {
    if (!isAdminLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function adminLogin($username, $password) {
    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_login_time'] = time();
        return true;
    }
    return false;
}

function adminLogout() {
    session_destroy();
    header('Location: index.php');
    exit;
}
?>