<?php
// process.php - Form Handler with TOKEN GENERATION
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'inc/config.php';
require_once 'inc/functions.php';
require_once 'inc/database.php';
require_once 'inc/send-email.php';
require_once 'inc/country-detection.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// Sanitize and collect data
$data = [
    'full_name' => sanitizeInput($_POST['full_name'] ?? ''),
    'email' => sanitizeInput($_POST['email'] ?? ''),
    'phone' => sanitizeInput($_POST['phone'] ?? ''),
    'vin' => strtoupper(sanitizeInput($_POST['vin'] ?? '')),
    'license_plate' => sanitizeInput($_POST['license_plate'] ?? ''),
    'vehicle_type' => sanitizeInput($_POST['vehicle_type'] ?? ''),
    'package' => sanitizeInput($_POST['package'] ?? '')
];

// Validation
if (empty($data['full_name']) || empty($data['email']) || empty($data['phone'])) {
    $_SESSION['error'] = 'Please fill all required fields';
    header('Location: index.php');
    exit;
}

if (empty($data['vin']) && empty($data['license_plate'])) {
    $_SESSION['error'] = 'Please enter either VIN or License Plate';
    header('Location: index.php');
    exit;
}

if (!isset($_POST['agreement'])) {
    $_SESSION['error'] = 'Please agree to the terms and conditions';
    header('Location: index.php');
    exit;
}

// Save to database
$saveResult = saveFormData($data);

if (!$saveResult) {
    logError("Failed to save form data for email: " . $data['email']);
    $_SESSION['error'] = 'Something went wrong. Please try again.';
    header('Location: index.php');
    exit;
}

// Get pricing for amount
$country = getUserCountry();
$pricing = getPricingByCountry($country);

$packagePrice = [
    'basic' => $pricing['basic'],
    'premium' => $pricing['premium'],
    'ultimate' => $pricing['ultimate']
];
$amount = $packagePrice[$data['package']] ?? '$29';

// ============================================
// STEP 1: GENERATE RANDOM TOKEN
// ============================================
function generateRandomToken($length = 64) {
    return bin2hex(random_bytes($length / 2));
}

$token = generateRandomToken(64);

// ============================================
// STEP 2: SET EXPIRY TIME (5 MINUTES FROM NOW)
// ============================================
$expiryTime = gmdate('Y-m-d H:i:s', strtotime('+5 minutes'));

// ============================================
// STEP 3: PREPARE FORM DATA FOR JSON STORAGE
// ============================================
$formDataJson = json_encode([
    'full_name' => $data['full_name'],
    'email' => $data['email'],
    'phone' => $data['phone'],
    'vin' => $data['vin'],
    'license_plate' => $data['license_plate'],
    'vehicle_type' => $data['vehicle_type'],
    'package' => $data['package'],
    'amount' => $amount,
    'country' => $country
]);

// ============================================
// STEP 4: SAVE TOKEN IN DATABASE
// ============================================
$tokenSaved = savePaymentToken($token, $formDataJson, $expiryTime);

if (!$tokenSaved) {
    logError("Failed to save payment token for email: " . $data['email']);
    $_SESSION['error'] = 'Something went wrong. Please try again.';
    header('Location: index.php');
    exit;
}

// ============================================
// STEP 5: SEND EMAILS
// ============================================
sendUserConfirmation($data['email'], $data['full_name'], $data['vin'], $data['package'], $amount);
sendAdminNotification($data);

// Store in session for redirect
$_SESSION['form_data'] = $data;

// ============================================
// STEP 6: REDIRECT WITH TOKEN ONLY (NO RAW DATA IN URL)
// ============================================
header('Location: ' . PAYMENT_URL . '?token=' . $token);
exit;
?>