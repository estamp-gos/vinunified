<?php
// inc/send-email.php - Fully Responsive Table-Based Email Templates
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

// Logo URLs
$vinUnifiedLogo = 'https://vinunified.store/assets/images/vinunified-white.png';
$docukitLogo = 'https://img.stitchnhide.com//upload/6a01d1c6f3e59.png';

// ============================================
// CORE EMAIL FUNCTION
// ============================================
function sendEmail($to, $subject, $message) {
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: VinUnified Support <support@vinunified.store>" . "\r\n";
    $headers .= "Reply-To: support@vinunified.store" . "\r\n";
    
    $result = mail($to, $subject, $message, $headers);
    error_log("Email sent to: $to - Result: " . ($result ? "Success" : "Failed"));
    return $result;
}

// ============================================
// RESPONSIVE TABLE-BASED EMAIL TEMPLATE
// ============================================
function getEmailTemplate($type, $data) {
    global $vinUnifiedLogo, $docukitLogo;
    
    // Set content based on type
    if ($type == 'user_confirmation') {
        $title = "VIN Check Request Received";
        $greeting = "Hello " . htmlspecialchars($data['name']) . ",";
        $mainContent = "
            <p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'>Thank you for using <strong style='color:#6C63FF;'>VinUnified</strong>.</p>
            <p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'>We have received your request for VIN: <strong style='color:#6C63FF;'>{$data['vin']}</strong> with <strong style='color:#6C63FF;'>" . ucfirst($data['package']) . "</strong> package.</p>
           
            <p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'>After successful payment, your vehicle history report will be delivered to this email within minutes.</p>
            <table width='100%' cellpadding='0' cellspacing='0' style='background:#FFF3CD; border-radius:12px; margin:20px 0;'>
                <tr>
                    <td style='padding:15px;'>
                        <p style='margin:0; font-size:14px; color:#856404;'><strong>⚠️ Important:</strong> If you are not satisfied with the report, please contact us within 14 days for a free updated report or full refund.</p>
                    </td>
                </tr>
            </table>
        ";
    } 
    elseif ($type == 'admin_notification') {
        $title = "New VIN Check Request";
        $greeting = "Admin Notification,";
        $mainContent = "
            <p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'>A new form has been submitted on VinUnified.</p>
            <table width='100%' cellpadding='10' cellspacing='0' style='background:#F8F9FF; border-radius:12px; margin:15px 0;'>
                <tr><td style='color:#6C757D; border-bottom:1px solid #E5E7EB;'>Name:</td><td style='font-weight:600; border-bottom:1px solid #E5E7EB;'>{$data['full_name']}</td></tr>
                <tr><td style='color:#6C757D; border-bottom:1px solid #E5E7EB;'>Email:</td><td style='font-weight:600; border-bottom:1px solid #E5E7EB;'>{$data['email']}</td></tr>
                <tr><td style='color:#6C757D; border-bottom:1px solid #E5E7EB;'>Phone:</td><td style='font-weight:600; border-bottom:1px solid #E5E7EB;'>{$data['phone']}</td></tr>
                <tr><td style='color:#6C757D; border-bottom:1px solid #E5E7EB;'>VIN:</td><td style='font-weight:600; border-bottom:1px solid #E5E7EB;'>{$data['vin']}</td></tr>
                <tr><td style='color:#6C757D; border-bottom:1px solid #E5E7EB;'>Vehicle Type:</td><td style='font-weight:600; border-bottom:1px solid #E5E7EB;'>{$data['vehicle_type']}</td></tr>
                <tr><td style='color:#6C757D; border-bottom:1px solid #E5E7EB;'>Package:</td><td style='font-weight:600; border-bottom:1px solid #E5E7EB;'>" . ucfirst($data['package']) . "</td></tr>
                <tr><td style='color:#6C757D; border-bottom:1px solid #E5E7EB;'>IP Address:</td><td style='font-weight:600; border-bottom:1px solid #E5E7EB;'>{$_SERVER['REMOTE_ADDR']}</td></tr>
                <tr><td style='color:#6C757D;'>Status:</td><td style='color:#FF6B35; font-weight:600;'>Pending Payment</td></tr>
            </table>
            <p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'>Customer will be redirected to complete payment via <strong>Docukit</strong>.</p>
            <p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'><strong>No action needed until payment is completed.</strong></p>
        ";
        $buttonText = "View Dashboard";
        $buttonLink = "https://vinunified.store/admin/";
    }
    elseif ($type == 'payment_confirmation') {
        $title = "Payment Received - Report Ready";
        $greeting = "Hello " . htmlspecialchars($data['name']) . ",";
        $mainContent = "
            <p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'>Your payment of <strong style='color:#28A745;'>{$data['amount']}</strong> has been successfully received via <strong>Docukit</strong>.</p>
            <p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'>Your vehicle history report for VIN: <strong style='color:#6C63FF;'>{$data['vin']}</strong> is now ready.</p>
            <table width='100%' cellpadding='0' cellspacing='0' style='background:#E8F6EF; border-radius:12px; margin:20px 0;'>
                <tr>
                    <td style='padding:15px;'>
                        <p style='margin:0; font-size:14px; color:#28A745;'><strong>✓ Payment Completed</strong> | Package: " . ucfirst($data['package']) . "</p>
                    </td>
                </tr>
            </table>
        ";
        $buttonText = "Download Report";
        $buttonLink = "https://vinunified.store/assets/pdf/sample-report.pdf";
    }
    else {
        $title = "VinUnified Update";
        $greeting = "Hello,";
        $mainContent = "<p style='margin:0 0 15px; font-size:15px; line-height:1.5; color:#333;'>Thank you for using VinUnified.</p>";
        $buttonText = "Visit Website";
        $buttonLink = "https://vinunified.store";
    }
    
    // Fully responsive table-based email template
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>' . $title . '</title>
        <style>
            @media only screen and (max-width: 600px) {
                .container { width: 100% !important; }
                .btn { display: block !important; width: 100% !important; text-align: center !important; }
                .inner-padding { padding: 20px !important; }
            }
        </style>
    </head>
    <body style="margin:0; padding:20px; background-color:#F0F2F5; font-family: Arial, Helvetica, sans-serif;">
        <table width="100%" cellpadding="0" cellspacing="0" align="center" style="max-width:600px; margin:0 auto; background-color:#F0F2F5;">
            <tr>
                <td style="padding:20px;">
                    <table width="100%" cellpadding="0" cellspacing="0" style="background:#FFFFFF; border-radius:24px; overflow:hidden; box-shadow:0 4px 12px rgba(0,0,0,0.05);">
                        <!-- Header -->
                        <tr>
                            <td style="background:linear-gradient(135deg, #6C63FF, #00B4D8); padding:30px; text-align:center;">
                                <img src="' . $vinUnifiedLogo . '" alt="VinUnified" style="height:50px; margin-bottom:10px;">
                                <h2 style="color:#FFFFFF; margin:10px 0 0; font-size:22px; font-weight:600;">' . $title . '</h2>
                            </td>
                        </tr>
                        <!-- Body -->
                        <tr>
                            <td style="padding:30px;">
                                <p style="font-size:16px; font-weight:600; color:#03045E; margin:0 0 20px;">' . $greeting . '</p>
                                ' . $mainContent . '
                                
                                <hr style="border:none; border-top:1px solid #E5E7EB; margin:20px 0;">
                                <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:20px;">
                                    <tr>
                                        <td align="center">
                                            <a href="mailto:support@vinunified.store?subject=Cancel Order - ' . ($data['vin'] ?? '') . '" style="color:#6C757D; text-decoration:none; margin-right:20px; font-size:13px;">❌ Cancel Order</a>
                                            <a href="mailto:support@vinunified.store?subject=Refund Request - ' . ($data['vin'] ?? '') . '" style="color:#6C63FF; text-decoration:none; font-size:13px;">💰 Request Refund</a>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <!-- Footer -->
                        <tr>
                            <td style="background:#03045E; padding:25px; text-align:center;">
                               
                                <p style="margin:15px 0 0; font-size:11px; color:#8AA0B5;">© 2026 VinUnified | One VIN. Global History.</p>
                                <p style="margin:10px 0 0;"><a href="mailto:support@vinunified.store" style="color:#6C63FF; text-decoration:none; font-size:11px;">support@vinunified.store</a></p>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>';
    
    return $html;
}

// ============================================
// USER CONFIRMATION EMAIL
// ============================================
function sendUserConfirmation($userEmail, $userName, $vin, $package, $amount = '$29') {
    $subject = "VinUnified - VIN Check Request Received";
    $data = ['name' => $userName, 'vin' => $vin, 'package' => $package, 'amount' => $amount];
    $message = getEmailTemplate('user_confirmation', $data);
    return sendEmail($userEmail, $subject, $message);
}

// ============================================
// ADMIN NOTIFICATION EMAIL
// ============================================
function sendAdminNotification($data) {
    $to = 'ceo@docukit.site, car.check.store@gmail.com';
    $subject = "New VIN Check Request";
    $emailData = [
        'name' => 'Admin',
        'full_name' => $data['full_name'],
        'email' => $data['email'],
        'phone' => $data['phone'],
        'vin' => $data['vin'],
        'vehicle_type' => $data['vehicle_type'],
        'package' => $data['package']
    ];
    $message = getEmailTemplate('admin_notification', $emailData);
    error_log("Admin email attempting to: $to");
    return sendEmail($to, $subject, $message);
}

// ============================================
// PAYMENT CONFIRMATION EMAIL
// ============================================
function sendPaymentConfirmation($userEmail, $userName, $vin, $package, $amount) {
    $subject = "Payment Confirmed - Your VinUnified Report is Ready";
    $data = ['name' => $userName, 'vin' => $vin, 'package' => $package, 'amount' => $amount];
    $message = getEmailTemplate('payment_confirmation', $data);
    return sendEmail($userEmail, $subject, $message);
}
?>