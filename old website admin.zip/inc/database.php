<?php
// inc/database.php - Database Functions
require_once __DIR__ . '/config.php';

// ============================================
// ORIGINAL FUNCTIONS (Unchanged)
// ============================================

function saveFormData($data) {
    $pdo = getDBConnection();
    if (!$pdo) return false;
    
    $stmt = $pdo->prepare("INSERT INTO vin_requests 
        (full_name, email, phone, vin, license_plate, vehicle_type, package, ip_address, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())");
    
    return $stmt->execute([
        $data['full_name'],
        $data['email'],
        $data['phone'],
        $data['vin'],
        $data['license_plate'],
        $data['vehicle_type'],
        $data['package'],
        $_SERVER['REMOTE_ADDR']
    ]);
}

function updateStatus($id, $status) {
    $pdo = getDBConnection();
    if (!$pdo) return false;
    
    $stmt = $pdo->prepare("UPDATE vin_requests SET status = ? WHERE id = ?");
    return $stmt->execute([$status, $id]);
}

function getRequestById($id) {
    $pdo = getDBConnection();
    if (!$pdo) return null;
    
    $stmt = $pdo->prepare("SELECT * FROM vin_requests WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function deleteOldRecords() {
    $pdo = getDBConnection();
    if (!$pdo) return false;
    
    $stmt = $pdo->prepare("DELETE FROM vin_requests WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
    return $stmt->execute();
}

// ============================================
// NEW FUNCTIONS FOR TOKEN MANAGEMENT
// ============================================

/**
 * Save payment token with form data
 * @param string $token - Random generated token
 * @param string $formDataJson - JSON encoded form data
 * @param string $expiryTime - Expiry datetime (Y-m-d H:i:s)
 * @return bool - True on success, false on failure
 */
function savePaymentToken($token, $formDataJson, $expiryTime) {
    $pdo = getDBConnection();
    if (!$pdo) return false;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO payment_tokens 
            (token, form_data, expiry_time, used, created_at) 
            VALUES (?, ?, ?, 0, NOW())");
        
        return $stmt->execute([$token, $formDataJson, $expiryTime]);
    } catch (PDOException $e) {
        logError("savePaymentToken Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Validate token and get form data
 * @param string $token - Token to validate
 * @return array|false - Returns form data array on success, false on failure
 */
function validateAndGetTokenData($token) {
    $pdo = getDBConnection();
    if (!$pdo) return false;
    
    try {
        // Check if token exists, not expired, and not used
        $stmt = $pdo->prepare("SELECT * FROM payment_tokens 
            WHERE token = ? 
            AND expiry_time > NOW() 
            AND used = 0 
            LIMIT 1");
        
        $stmt->execute([$token]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$result) {
            return false;
        }
        
        // Decode JSON form data
        $formData = json_decode($result['form_data'], true);
        
        if (!$formData) {
            return false;
        }
        
        // Mark token as used (so it can't be used again)
        $updateStmt = $pdo->prepare("UPDATE payment_tokens SET used = 1 WHERE token = ?");
        $updateStmt->execute([$token]);
        
        return $formData;
        
    } catch (PDOException $e) {
        logError("validateAndGetTokenData Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if token is valid without marking as used
 * @param string $token - Token to check
 * @return bool - True if valid, false otherwise
 */
function isTokenValid($token) {
    $pdo = getDBConnection();
    if (!$pdo) return false;
    
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM payment_tokens 
            WHERE token = ? 
            AND expiry_time > NOW() 
            AND used = 0");
        
        $stmt->execute([$token]);
        $count = $stmt->fetchColumn();
        
        return ($count > 0);
        
    } catch (PDOException $e) {
        logError("isTokenValid Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Delete expired tokens (cleanup)
 * @return int - Number of deleted rows
 */
function deleteExpiredTokens() {
    $pdo = getDBConnection();
    if (!$pdo) return 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM payment_tokens WHERE expiry_time < NOW()");
        $stmt->execute();
        return $stmt->rowCount();
        
    } catch (PDOException $e) {
        logError("deleteExpiredTokens Error: " . $e->getMessage());
        return 0;
    }
}

/**
 * Delete used tokens older than X days (cleanup)
 * @param int $days - Days to keep used tokens (default 7)
 * @return int - Number of deleted rows
 */
function deleteOldUsedTokens($days = 7) {
    $pdo = getDBConnection();
    if (!$pdo) return 0;
    
    try {
        $stmt = $pdo->prepare("DELETE FROM payment_tokens 
            WHERE used = 1 
            AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)");
        
        $stmt->execute([$days]);
        return $stmt->rowCount();
        
    } catch (PDOException $e) {
        logError("deleteOldUsedTokens Error: " . $e->getMessage());
        return 0;
    }
}
?>