<?php
// cleanup-tokens.php - Delete expired and old used tokens
// This script can be run via cron job or manually

require_once __DIR__ . '/database.php';

// Delete expired tokens (expiry_time < NOW)
$deletedExpired = deleteExpiredTokens();

// Delete used tokens older than 7 days
$deletedOldUsed = deleteOldUsedTokens(7);

// Log the cleanup
$logMessage = date('Y-m-d H:i:s') . " - Deleted expired: $deletedExpired, Deleted old used: $deletedOldUsed" . PHP_EOL;
file_put_contents(__DIR__ . '/../logs/cleanup.log', $logMessage, FILE_APPEND);

echo "Cleanup completed. Expired: $deletedExpired, Old Used: $deletedOldUsed\n";
?>