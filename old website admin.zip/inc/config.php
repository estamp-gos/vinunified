<?php
// inc/config.php - Database & Email Configuration (Titan Mail)
// NO session_start() here - session started in index.php and process.php only

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'u854130977_vinunified');
define('DB_USER', 'u854130977_admin');
define('DB_PASS', 'Admin123#sgjfdsgjhf782634');

// Site Configuration
define('SITE_URL', 'https://vinunified.store');
define('SITE_NAME', 'VinUnified');
define('SITE_EMAIL', 'inquiry@vinunified.store'); // ✅ CHANGED - Admin email for notifications

// Titan Mail SMTP Configuration
define('SMTP_HOST', 'smtp.titan.email');
define('SMTP_PORT', 465);
define('SMTP_SECURE', 'ssl');
define('SMTP_USER', 'support@vinunified.store');
define('SMTP_PASS', 'Admin123#sgjfdsgjhf782634');
define('SMTP_FROM', 'support@vinunified.store');
define('SMTP_FROM_NAME', 'VinUnified Support');

// Payment Redirect URL
define('PAYMENT_URL', 'https://payments.docukit.site/index.php');

// Error Reporting (Debug ON - will turn off later)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Asia/Karachi');

// Database Connection
function getDBConnection() {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch(PDOException $e) {
        error_log("Database Connection Error: " . $e->getMessage());
        return null;
    }
}
?>