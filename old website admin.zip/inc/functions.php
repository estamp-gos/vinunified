<?php
// inc/functions.php - Helper Functions

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function validateVIN($vin) {
    $vin = strtoupper(preg_replace('/[^A-Z0-9]/', '', $vin));
    return (strlen($vin) == 17);
}

function generateOrderID() {
    return 'VIN-' . strtoupper(uniqid());
}

function logError($message) {
    $logFile = __DIR__ . '/../logs/error.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message" . PHP_EOL, FILE_APPEND);
}
?>